/*
* Add NetID and names of all project partners
* Course: CS 416/518
* NetID: ki120, bys8
* Name: Kelvin Ihezue, Bryan Shangguan
*/

#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>

int main() {
    printf("Hello, World!\n");

    return 0;
}
